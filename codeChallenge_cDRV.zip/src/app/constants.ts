export const validationMessages = {
    'variety' : 'password should contain at least one lowercase letter and number',
    'length' : 'password should be between 5 & 12 characters long',
    'duplicates' : 'password should not contain repeating characters'
}
